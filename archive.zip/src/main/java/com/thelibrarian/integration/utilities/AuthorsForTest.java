package com.thelibrarian.integration.utilities;

public enum AuthorsForTest {
    KING,
    BILL,
    SAM,
    TOM,
    PHILIP,
    JOHN,
    RIVERA,
    DAVID,
    PETER,
    AGATHA,
    STEVEN,
    BRAD,
    MARY
}
