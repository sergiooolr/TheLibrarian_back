package com.thelibrarian.integration.utilities;

public enum TitlesForTest {
    WAR,
    SUN,
    HAPPY,
    FLOWER,
    NIGHT,
    MAN,
    DAY,
    LOVE,
    RAIN,
    TRAIN,
    SPACE,
    TRUE,
    GREAT,
    SKY,
    TRUTH
}
