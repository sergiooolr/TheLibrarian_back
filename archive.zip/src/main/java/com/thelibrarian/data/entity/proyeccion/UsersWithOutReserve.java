package com.thelibrarian.data.entity.proyeccion;

public interface UsersWithOutReserve {
    Integer getId();
    String getNombre();
    String getCorreo();
}
