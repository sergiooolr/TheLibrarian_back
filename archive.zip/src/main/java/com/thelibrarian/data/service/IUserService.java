package com.thelibrarian.data.service;

public interface IUserService {
}
